// This file is part of Golly.
// See docs/License.html for the copyright notice.

@interface StatePickerView : UIView <UIGestureRecognizerDelegate>

@end
