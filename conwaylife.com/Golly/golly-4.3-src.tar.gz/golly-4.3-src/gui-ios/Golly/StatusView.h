// This file is part of Golly.
// See docs/License.html for the copyright notice.

// This is the view for displaying Golly's status info.

@interface StatusView : UIView

@end
